package com.springInitializr.servicios;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiciosApplicationTests {

	@Test
	void contextLoads() {
	}

}
